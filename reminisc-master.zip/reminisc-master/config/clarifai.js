module.exports = {
    "CLIENT_ID": "***REMOVED***",
    "SECRET": "***REMOVED***"
}
