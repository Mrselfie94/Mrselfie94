module.exports = {
    'facebookAuth' : {
        'clientID': '***REMOVED***',
        'clientSecret': '***REMOVED***',
        'callbackURL': 'http://reminisc.org/api/auth/callback'
    }
};
